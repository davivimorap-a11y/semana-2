clave_fija = 1234

while True:
    clave = int(input("Ingrese la contraseña numérica: "))

    if clave == clave_fija:
        print("¡Bienvenido!")
        break
    else:
        print("Clave incorrecta. Intente nuevamente.")