while True:
    print("--- Bienvenido al menú ---")
    print("1. Consultar")
    print("2. Registrar")
    print("3. Salir")

    respuesta = int(input("Seleccione una opción: "))

    if respuesta == 1:
        print("Ud seleccionó Consultar")
    elif respuesta == 2:
        print("Ud seleccionó Registrar")
    elif respuesta == 3:
        print("Ud seleccionó Salir")
        break
    else:
        print("Opción equivocada")