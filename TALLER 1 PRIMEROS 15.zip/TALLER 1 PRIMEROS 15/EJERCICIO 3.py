clave_fija = 1234
intentos = 0

while intentos < 3:
    clave = int(input("Ingrese la contraseña numérica: "))

    if clave == clave_fija:
        print("Acceso concedido")
        break
    else:
        intentos += 1
        print("Clave incorrecta")

if intentos == 3:
    print("Cuenta bloqueada")