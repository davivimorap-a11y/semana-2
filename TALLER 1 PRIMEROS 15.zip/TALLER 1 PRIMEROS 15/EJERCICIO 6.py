while True:
    documento = input("Ingrese su tipo de documento (CC, TI o CE): ").upper()

    if documento == "CC" or documento == "TI" or documento == "CE":
        print("Tipo de documento válido:", documento)
        break
    else:
        print("Error: tipo de documento inválido. Intente nuevamente.")