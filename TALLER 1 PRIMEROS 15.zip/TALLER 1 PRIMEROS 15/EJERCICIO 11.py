numero = int(input("Ingrese un número entero positivo: "))

while numero < 0:
    print("Error: ingrese un número positivo.")
    numero = int(input("Ingrese un número entero positivo: "))

factorial = 1
contador = 1

while contador <= numero:
    factorial *= contador
    contador += 1

print("El factorial es:", factorial)