respuesta = "S"

while respuesta == "S" or respuesta == "s":
    print("Procesando solicitud...")
    print("Operación finalizada.")

    respuesta = input("¿Desea realizar otra operación? (S/N): ")

print("Programa finalizado.")	