while True:
    nota = float(input("Ingrese una calificación entre 0.0 y 5.0: "))

    if nota >= 0.0 and nota <= 5.0:
        print("Nota válida. Puede continuar.")
        break
    else:
        print("Error: la nota debe estar entre 0.0 y 5.0. Intente nuevamente.")