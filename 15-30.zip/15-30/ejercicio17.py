
total = 0

while True:
    precio = float(input("Ingrese el precio del producto: "))

    if precio == 0:
        break

    if precio < 0:
        print("El precio no puede ser negativo")
    else:
        total = total + precio

print("Total a pagar: $", total)
