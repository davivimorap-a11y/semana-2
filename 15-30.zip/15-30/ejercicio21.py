
presentes = 0
ausentes = 0

while True:
    asistencia = input("Ingrese P, A o F para finalizar: ").upper()

    if asistencia == "P":
        presentes = presentes + 1

    elif asistencia == "A":
        ausentes = ausentes + 1

    elif asistencia == "F":
        break

    else:
        print("Opción incorrecta")

print("Total presentes:", presentes)
print("Total ausentes:", ausentes)
