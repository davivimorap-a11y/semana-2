
numero = int(input("Ingrese un número entero positivo: "))

if numero < 0:
    print("Debe ingresar un número positivo")
elif numero == 0:
    print(0)
else:
    while numero > 0:
        digito = numero % 10

        print(digito)

        numero = numero // 10
