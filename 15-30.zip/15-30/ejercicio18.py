
saldo = 500000

while saldo > 0:
    print("Saldo disponible: $", saldo)

    retiro = int(input("Ingrese el valor a retirar (0 para salir): "))

    if retiro == 0:
        break

    elif retiro < 0:
        print("Ingrese un valor válido")

    elif retiro > saldo:
        print("Error: saldo insuficiente")

    else:
        saldo = saldo - retiro
        print("Retiro exitoso")

print("Transacción finalizada")
print("Saldo restante: $", saldo)
