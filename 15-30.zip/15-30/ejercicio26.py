
maximo = None

while True:
    numero = float(input("Ingrese un número (0 para terminar): "))

    if numero == 0:
        break

    if maximo is None or numero > maximo:
        maximo = numero

if maximo is None:
    print("No se ingresaron números")
else:
    print("El número mayor es:", maximo)
