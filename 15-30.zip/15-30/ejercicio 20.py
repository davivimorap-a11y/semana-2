
deuda = float(input("Ingrese el valor de la deuda: "))
meses = int(input("Ingrese los meses en mora: "))

if deuda < 0 or meses < 0:
    print("Los valores no pueden ser negativos")
else:
    for mes in range(1, meses + 1):
        deuda = deuda + (deuda * 0.05)

        print("Deuda en el mes", mes, ":", round(deuda, 2))

    print("Saldo final adeudado: $", round(deuda, 2))
