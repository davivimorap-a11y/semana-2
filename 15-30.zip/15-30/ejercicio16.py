print("Múltiplos de 5")

for numero in range(5, 51, 5):
    print(numero)
