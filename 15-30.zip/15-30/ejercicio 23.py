
import random

secreto = random.randint(1, 10)

while True:
    numero = int(input("Adivine el número entre 1 y 10: "))

    if numero > secreto:
        print("El número ingresado es mayor al secreto")

    elif numero < secreto:
        print("El número ingresado es menor al secreto")

    else:
        print("¡Felicidades! Adivinaste el número")
        break
