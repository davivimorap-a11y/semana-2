
import random

dado = 0

while dado != 6:
    dado = random.randint(1, 6)

    print("Resultado del lanzamiento:", dado)

print("¡Salió el número 6!")
print("Juego terminado")
