
capacidad = 5
personas = 0

while personas < capacidad:
    personas = personas + 1

    print("Ingresó la persona número:", personas)

print("Aforo completo")
