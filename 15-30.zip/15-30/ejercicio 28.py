
numero = int(input("Ingrese un número entero positivo: "))

divisores = 0

if numero <= 0:
    print("Debe ingresar un número positivo")

else:
    for i in range(1, numero + 1):

        if numero % i == 0:
            divisores = divisores + 1

    if divisores == 2:
        print("El número es primo")

    else:
        print("El número no es primo")
