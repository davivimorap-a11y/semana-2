from django.db import models

# Create your models here.
class aprendiz (models.Model):
    nombre  = models.CharField(max_length = 25)
    apellido = models.CharField(max_length = 25)
    documento = models.IntegerField(unique = True)
    correo = models.EmailField(unique = True)
    telefono = models.IntegerField(unique=True)
    ficha = models.IntegerField()
    tipo_de_documento = models.CharField(max_length = 25)



    def _str_(self):      
        return f"{self.nombre} {self.apellido} - Doc: {self.documento} - Ficha: {self.ficha}"

        

class programa (models.Model):
    nombre  = models.CharField(max_length = 25)
    ficha = models.IntegerField()
    jornada =  models.CharField(max_length = 15)
    lugar =  models.CharField(max_length = 50)
    duracion =  models.CharField(max_length = 15)
    modalidad =  models.CharField(max_length = 15)
    nivel_de_profesionalismo = models.CharField(max_length = 15)
    descripcion = models.TextField()



def _str_(self):      
        return f"{self.nombre} {self.ficha} - Doc: {self.descripcion} - Ficha: {self.nivel_de_profesionalismo } {self.duracion} {self.ficha} {self.modalidad}"



class instructores (models.Model):
    nombre  = models.CharField(max_length = 25)
    apellido = models.CharField(max_length = 25)
    especialidad = models.CharField(max_length = 25)
    documento = models.IntegerField(unique = True)
    ficha_asignada = models.CharField(max_length = 25)
    correo = models.EmailField(unique = True)
    telefono = models.IntegerField(unique=True)

def _str_(self):      
        return f"{self.nombre} {self.apellido} {self.especialidad} - Doc: {self.documento} - Ficha: {self.ficha_asignada}"


class competencias (models.Model):
    nombre  = models.CharField(max_length = 25)
    ficha = models.IntegerField()
    instructores  = models.CharField(max_length = 25)


def _str_(self):      
        return f"{self.nombre} {self.instructores} - Ficha: {self.ficha}"





    

    



